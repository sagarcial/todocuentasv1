<?php 
session_start();
error_reporting(0);

$usuarioa =$_SESSION['usuario'];
$conn = mysqli_connect("localhost", "root", "", "sistema_usuarios");
// comprobar la conexión
if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
  }
  
  // realizar la consulta SQL con la cláusula WHERE
  $sql = "SELECT nombre, usuario,contrasena,vendedor,limite_uso_web FROM usuarios";
  $resultado = mysqli_query($conn, $sql);



// Consulta para sumar los valores de la columna "creditos" de la tabla "admin"
$query = "SELECT SUM(creditos) as total_creditos FROM admin";
$resultado2 = mysqli_query($conn, $query);

// Verificar si la consulta fue exitosa
if ($resultado2) {
    // Obtener el resultado de la consulta como un array asociativo
    $fila = mysqli_fetch_assoc($resultado2);

    // Guardar el resultado de la suma en una variable
    $total_creditos = $fila['total_creditos'];

} else {
    echo "Error al sumar los créditos: " . mysqli_error($conn);
}


  ?>
