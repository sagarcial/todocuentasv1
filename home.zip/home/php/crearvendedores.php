<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_usuarios";

// Crea una conexión
$mysqli = new mysqli($servername, $username, $password, $dbname);

// Verifica la conexión
if ($conn->connect_error) {
  die("Conexión fallida: " . $conn->connect_error);
}

// Verifica si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Obtiene los valores del formulario
  $nombre = $_POST["nombre"];
  $usuario = $_POST["usuario"];
  $creditos = $_POST["creditos"];
  $contrasena = $_POST["contrasena"];

  // Prepara la consulta SQL
  $query = "INSERT INTO admin (nombre, usuario, creditos, contrasena)
  VALUES ('$nombre', '$usuario', '$creditos', '$contrasena')";

  // Ejecuta la consulta
  if ($mysqli->query($query) === TRUE) {
    header('Location: ../vendedores.php');
} else {
    header('Location: ../crearvendedores.php?Error="false"');
}
}

// Cierra la conexión
$conn->close();
?>
