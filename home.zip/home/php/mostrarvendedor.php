<?php 
session_start();
error_reporting(0);

$usuarioa =$_SESSION['usuario'];
$conn = mysqli_connect("localhost", "root", "", "sistema_usuarios");
// comprobar la conexión
if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
  }
  
  // realizar la consulta SQL con la cláusula WHERE
  $sql = "SELECT nombre, usuario,contrasena,limite_uso_web FROM usuarios WHERE vendedor='$usuarioa'";
  $resultado = mysqli_query($conn, $sql);
  ?>
