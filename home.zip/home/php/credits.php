<?php
//Conectar con la base de datos
$mysqli = new mysqli("localhost", "root", "", "sistema_usuarios");

$usuarioa =$_SESSION['usuario'];

//Comprobar la conexión
if ($mysqli -> connect_errno) {
  echo "Error al conectar con la base de datos: " . $mysqli -> connect_error;
  exit();
}

//Obtener los créditos del usuario administrador
$query = "SELECT creditos FROM admin WHERE usuario='$usuarioa'";
$result = $mysqli->query($query);
$credits = $result->fetch_assoc()['creditos'];
$mysqli->close();
?>
