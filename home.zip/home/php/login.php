<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_usuarios";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

date_default_timezone_set('America/Bogota'); // Establecer la zona horaria a Colombia

if (isset($_POST["usuario"]) && isset($_POST["contrasena"])) {
  // Si se han enviado los datos del formulario, procedemos con la consulta
  $usuarios = $_POST["usuario"];
  $contrasena = $_POST["contrasena"];
  $query = "SELECT * FROM usuarios WHERE usuario='$usuarios' AND contrasena='$contrasena'";
  $resultado = mysqli_query($conn, $query);

  if (mysqli_num_rows($resultado) == 1) {
    // Si el usuario existe, comprobamos la fecha límite
    $usuario = mysqli_fetch_assoc($resultado);
    $limite = $usuario['limite_uso_web'];
    $fecha_limite = strtotime($limite);
    $fecha_actual = time();

    if ($fecha_limite < $fecha_actual) {
      // Si la fecha límite ha expirado, redirigimos al usuario a index.php con un mensaje de error
      header("Location: ../index.php?error=1");
      exit();
    } else {
      // Si la fecha límite no ha expirado, permitimos el acceso a la página
	  ini_set('session.cookie_lifetime', 2592000); // 30 días en segundos
      ini_set('session.gc_maxlifetime', 2592000); // 30 días en segundos
      session_start();
      $_SESSION['usuario'] = $usuarios;
      $_SESSION['PERFIL'] = 'usuario';
      $_SESSION['FechaLimite'] = $limite;
      header("Location: ../tv/indextv.php");
      exit();
    }
  } else {
    // Si el usuario no existe en la base de datos, redirigimos al usuario a index.php con un mensaje de error
    header("Location: ../index.php?error=2");
    exit();
  }
} else {
  // Si no se han enviado los datos del formulario, redirigimos al usuario a login.php
  header("Location: ../index.php");
  exit();
}
?>

