<?php
session_start();
$usuarioa =$_SESSION['usuario'];
//Obtener los datos del formulario
$nombre = $_POST["nombre"];
$usuarios = $_POST["usuario"];
$contrasena = $_POST["contrasena"];
$plan = $_POST['plan'];
$vendedor = $_POST["vendedor"];

//Conectar con la base de datos
$mysqli = new mysqli("localhost", "root", "", "sistema_usuarios");
date_default_timezone_set('America/Bogota'); 

//Comprobar la conexión
if ($mysqli -> connect_errno) {
  echo "Error al conectar con la base de datos: " . $mysqli -> connect_error;
  exit();
}

//Obtener los créditos del usuario administrador
$query = "SELECT creditos FROM admin WHERE usuario='$usuarioa'";
$result = $mysqli->query($query);
$credits = $result->fetch_assoc()['creditos'];

//Calcular la cantidad de créditos necesarios
$credits_needed = 0;
if ($plan == "1") {
    $credits_needed = 1;
} elseif ($plan == "3") {
    $credits_needed = 3;
} elseif ($plan == "5") {
    $credits_needed = 5;
} elseif ($plan == "7") {
    $credits_needed = 7;
} elseif ($plan == "30") {
    $credits_needed = 30;
} elseif ($plan == "33") {
    $credits_needed = 33;
}
// Verificar si el usuario ya existe
$query = "SELECT COUNT(*) as count FROM usuarios WHERE usuario='$usuarios'";
$result = $mysqli->query($query);
$row = $result->fetch_assoc();
$count = $row['count'];

if ($count > 0) {
      echo "<script>alert('El usuario ya existe. Por favor, elige otro  nombre de usuario.'); window.history.back();</script>";
} else {
//Comprobar si el usuario administrador tiene suficientes créditos
if ($credits < $credits_needed) {
    echo "No tienes suficientes créditos para crear este usuario.";
} else {
    //Actualizar la cantidad de créditos del usuario administrador
    $new_credits = $credits - $credits_needed;
    $query = "UPDATE admin SET creditos=$new_credits WHERE usuario='$usuarioa'";
    $mysqli->query($query);

    //Calcular la fecha de vencimiento
    $expiry_date = date('Y-m-d', strtotime("+".$credits_needed." days"));

    //Insertar el nuevo usuario en la base de datos
    $query = "INSERT INTO usuarios (nombre,usuario,contrasena,limite_uso_web,vendedor) VALUES ('$nombre', '$usuarios', '$contrasena', '$expiry_date','$vendedor')";
    if ($mysqli->query($query) === TRUE) {
        header('Location: ../dashboard.php');
    } else {
        header('Location: ../crearusuariosvendedores.php?Error="false"');
    }
}
	}

//Cerrar la conexión con la base de datos
$mysqli->close();
?>
