<?php
    // Conectar a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "sistema_usuarios";
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verifica la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Verifica si se ha enviado el formulario de eliminación
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Obtiene el ID de la fila a eliminar desde el campo oculto del formulario
    $id_eliminar = $_POST['id'];

    // Prepara la consulta de eliminación
    $sql = "DELETE FROM usuarios WHERE id = $id_eliminar";

    // Ejecuta la consulta
    if ($conn->query($sql) === TRUE) {
        // Si la eliminación fue exitosa, redirige a la página anterior
        header("Location: ../dashboard.php");
        exit();
    } else {
        // Si hubo un error al ejecutar la consulta, muestra un mensaje de error
        echo "Error al eliminar el registro: " . $conn->error;
    }
}
?>
