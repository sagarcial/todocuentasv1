<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_usuarios";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$usuarios = $_POST["usuario"];
$contrasena = $_POST["contrasena"];

// Buscar en la tabla "admin"
$query = "SELECT * FROM admin WHERE usuario='$usuarios' AND contrasena='$contrasena'";
$resultado = mysqli_query($conn, $query);

if (mysqli_num_rows($resultado) == 1) {
	 ini_set('session.cookie_lifetime', 2592000); // 30 días en segundos
      ini_set('session.gc_maxlifetime', 2592000); // 30 días en segundos
    session_start();
    header("Location: ../dashboard.php");
    $fila = mysqli_fetch_assoc($resultado);
    $_SESSION['usuario'] = $usuarios;
    $_SESSION['PERFIL'] = 'vendedor';
    $_SESSION['creditos'] = $fila['creditos'];
    exit();
} 
else {
    // Si no se encuentra en la tabla "admin", buscar en la tabla "super_admin"
    $query = "SELECT * FROM superadmin WHERE usuario='$usuarios' AND contrasena='$contrasena'";
    $resultado = mysqli_query($conn, $query);

    if (mysqli_num_rows($resultado) == 1) {
		 ini_set('session.cookie_lifetime', 2592000); // 30 días en segundos
      ini_set('session.gc_maxlifetime', 2592000); // 30 días en segundos
        session_start();
        header("Location: ../dashboard_admin.php");
        $fila = mysqli_fetch_assoc($resultado);
        $_SESSION['usuario'] = $usuarios;
        $_SESSION['PERFIL'] = 'administrador';
        exit();
    } 
    else {
        header('Location: ../loginadm.php?Error="false"');
        exit();
    }
}
?>