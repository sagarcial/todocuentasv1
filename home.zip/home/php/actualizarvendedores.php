<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_usuarios";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
  die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $id = $_POST['id'];
  $nombre = $_POST['nombre'];
  $usuario = $_POST['usuario'];
  $creditos = $_POST['creditos'];
  $contrasena = $_POST['contrasena'];

  // Actualizar registro
  $query = "UPDATE admin SET nombre='$nombre', usuario='$usuario', creditos='$creditos' , contrasena='$contrasena' WHERE id=$id";
  $resultado = mysqli_query($conn, $query);

  if ($resultado) {
    // Si la actualización fue exitosa, redirigir al usuario a la página de la tabla
    header("Location: ../vendedores.php");
    exit();
  } else {
    // Si la actualización falló, mostrar un mensaje de error
    echo "Error al actualizar el registro: " . mysqli_error($conn);
  }
}
?>