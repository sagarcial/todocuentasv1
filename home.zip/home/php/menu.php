<?php 
session_start();
if (session_status() == PHP_SESSION_ACTIVE && isset($_SESSION["usuario"])) {
  // La sesión está activa y la variable de sesión "usuario" está definida, por lo que se permite el acceso a la página
} else {
  // La sesión no está activa o la variable de sesión "usuario" no está definida, por lo que se redirige a la página de inicio de sesión
  header("Location: login.php");
  exit();
}

?>

<?php 
$mysqli = new mysqli("localhost", "root", "", "sistema_usuarios");

$usuarioa =$_SESSION['usuario'];

//Comprobar la conexión
if ($mysqli -> connect_errno) {
  echo "Error al conectar con la base de datos: " . $mysqli -> connect_error;
  exit();
}

//Obtener los créditos del usuario administrador
$query = "SELECT creditos FROM admin WHERE usuario='$usuarioa'";
$result = $mysqli->query($query);
$mysqli->close();
?>
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
<style>
    .bg-gradient-primary {
    background-color: #00dfff;
    background-image: linear-gradient(180deg,#ffffff 10%,#ffffff 100%);
    background-size: cover;
    
}
.sidebar-dark .nav-item .nav-link {
    color: rgb(0 0 0 / 80%);
}
.sidebar-dark .nav-item .nav-link i {
    color: rgb(0 0 0);
}
body {
    margin: 0;
    font-family: Nunito,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";
    font-size: 1rem;
    font-weight: 800;
    line-height: 1.5;
    color: #858796;
    text-align: left;
    background-color: #fff;
}
.text-primary {
    color: #9f00ff!important;
}
.btn-primary {
    color: #fff;
    background-color: #6e00ff;
    border-color: #4e73df;
}


</style>

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="http://multitv.biz/dashboard.php">
    <div class="sidebar-brand-icon rotate-n-15">
    <img src="img/logo.png" width=60px>
    </div>
</a>

<!-- Divider -->
<hr class="sidebar-divider my-0">
<?php 
if ($_SESSION['PERFIL']=="vendedor"){
    $credits = $result->fetch_assoc()['creditos'];

	?>
<!-- Nav Item - Dashboard -->
<li class="nav-item">
    <a class="nav-link" href="dashboard.php">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Inicio</span></a>
</li>


<li class="nav-item">
    <a class="nav-link"  href="crearusuariosvendedores.php">
        <i class="fas fa-fw fa-cog"></i>
        <span>Registro Usuarios</span></a>
</li>
<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

</ul>
     <!-- Content Wrapper -->
     <div id="content-wrapper" class="d-flex flex-column">

<!-- Main Content -->
<div id="content">

    <!-- Topbar -->
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

        <!-- Sidebar Toggle (Topbar) -->
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>

        <!-- Topbar Navbar -->
        <ul class="navbar-nav ml-auto">

          

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="mr-2 d-none d-lg-inline text-gray-600 small"> Bienvenido <?php echo $_SESSION['usuario'] ;?> </span>
                    <span class="mr-2 d-none d-lg-inline text-gray-600 small"> Creditos  <?php echo $credits ;?> </span>
                    <img class="img-profile rounded-circle"
                        src="img/undraw_profile.svg">
                </a>
                <!-- Dropdown - User Information -->
                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                    aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                      Salir
                    </a>
                </div>
            </li>

        </ul>

    </nav>
    <?php  
	}elseif ($_SESSION['PERFIL']=="administrador"){
	?>
    <!-- Nav Item - Dashboard -->
<li class="nav-item">
    <a class="nav-link" href="dashboard_admin.php">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Inicio</span></a>
</li>


<li class="nav-item">
    <a class="nav-link"  href="vendedores.php">
        <i class="fas fa-fw fa-cog"></i>
        <span>Consultar Vendedores</span></a>
</li>


<li class="nav-item">
    <a class="nav-link"  href="crearvendedores.php">
        <i class="fas fa-fw fa-cog"></i>
        <span>Registro Vendedores</span></a>
</li>


<li class="nav-item">
    <a class="nav-link"  href="crearusuariosavendedoresdmin.php">
        <i class="fas fa-fw fa-cog"></i>
        <span>Registro Usuarios</span></a>
</li>
<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

</ul>
     <!-- Content Wrapper -->
     <div id="content-wrapper" class="d-flex flex-column">

<!-- Main Content -->
<div id="content">

    <!-- Topbar -->
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

        <!-- Sidebar Toggle (Topbar) -->
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>

        <!-- Topbar Navbar -->
        <ul class="navbar-nav ml-auto">

          

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="mr-2 d-none d-lg-inline text-gray-600 small"> Bienvenido <?php echo $_SESSION['usuario'] ;?> </span>
                    <span class="mr-2 d-none d-lg-inline text-gray-600 small"> Eres Admin</span>
                    <img class="img-profile rounded-circle"
                        src="img/undraw_profile.svg">
                </a>
                <!-- Dropdown - User Information -->
                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                    aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                      Salir
                    </a>
                </div>
            </li>

        </ul>

    </nav>
       <?php  
	}elseif ($_SESSION['PERFIL']=="usuario"){
        $fecha_vencimiento = $_SESSION['FechaLimite'];
        $dias_restantes = floor((strtotime($fecha_vencimiento) - strtotime(date('Y-m-d'))) / 86400);
      
	?>
    <!-- Nav Item - Dashboard -->
<li class="nav-item">
    <a class="nav-link" href="canales.php">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Canales</span></a>
</li>
<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

</ul>
     <!-- Content Wrapper -->
     <div id="content-wrapper" class="d-flex flex-column">

<!-- Main Content -->
<div id="content">

    <!-- Topbar -->
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

        <!-- Sidebar Toggle (Topbar) -->
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>

        <!-- Topbar Navbar -->
        <ul class="navbar-nav ml-auto">

          

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="mr-2 d-none d-lg-inline text-gray-600 small"> Bienvenido <?php echo $_SESSION['usuario'] ;?> </span>
                    <span class="mr-2 d-none d-lg-inline text-gray-600 small"> Dias Restantes <?php echo $dias_restantes ;?></span>
                    <img class="img-profile rounded-circle"
                        src="img/undraw_profile.svg">
                </a>
                <!-- Dropdown - User Information -->
                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                    aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                      Salir
                    </a>
                </div>
            </li>

        </ul>

    </nav>
    <?php 
	}
	?>
    <!-- End of Topbar -->

