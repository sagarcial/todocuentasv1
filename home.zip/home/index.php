<?php

if (isset($_GET['error'])) {
  $error = $_GET['error'];

  if ($error == 1) {
    $mensaje = "La fecha límite ha expirado. Por favor, ponte en contacto con tu distribuidor.";
  } elseif ($error == 2) {
    $mensaje = "Usuario o contraseña incorrectos.";
  } else {
    $mensaje = "Ocurrió un error desconocido.";
  }
}

?>

<!doctype html>
<html lang="en">
  <head>
  	<title>FUTYSEX</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="css/style.css">

	</head>
	<body>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
			</div>
			<div class="row justify-content-center">
				<div class="col-md-12 col-lg-10">
					<div class="wrap d-md-flex">
						<div class="img" style="background-image: url(images/xde.png);">
			      </div>
						<div class="login-wrap p-4 p-md-5">
			      	<div class="d-flex">
			      		<div class="w-100">
			      			<h3 class="mb-4">INICIAR SESION</h3>
							  <p class="mb-0" style="color:#FF0000">
								<?php if (isset($mensaje)): ?>
				<?php echo $mensaje; ?>
				<?php endif; ?>
			  
									   </p>
			      		</div>
								
			      	</div>
							<form  action="php/login.php" method="post" class="signin-form">
			      		<div class="form-group mb-3">
			      			<label class="label" for="name">Usuario</label>
			      			<input type="text" class="form-control" name="usuario" placeholder="Usuario" required>
			      		</div>
		            <div class="form-group mb-3">
		            	<label class="label" for="password">Contraseña</label>
		              <input type="password" class="form-control" name="contrasena" placeholder="Contraseña" required>
		            </div>
		            <div class="form-group">
		            	<button type="submit" class="form-control btn btn-primary rounded submit px-3">Iniciar Sesion</button>
		            </div>
		          </form>
		          <p class="text-center"> <a href="loginadm.php">Eres Vendedor?</a></p>
		        </div>
		      </div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
</html>

