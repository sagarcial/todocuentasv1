<?php 
date_default_timezone_set('America/Bogota'); 
$marca_tiempo = date('H:i Y-m-d '); 
$marca_tiempo1= date('Y-m-d'); 



session_start();
if (session_status() == PHP_SESSION_ACTIVE && isset($_SESSION["usuario"])) {
  // La sesión está activa y la variable de sesión "usuario" está definida, por lo que se permite el acceso a la página
} else {
  // La sesión no está activa o la variable de sesión "usuario" no está definida, por lo que se redirige a la página de inicio de sesión
  header("Location: ../index.php");
  exit();
}
$fecha_vencimiento = $_SESSION['FechaLimite'];
$dias_restantes = floor((strtotime($fecha_vencimiento) - strtotime(date('Y-m-d'))) / 86400);
$fecha1 = new DateTime(); // Fecha actual
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<style>
    .dropdown {
      position: relative;
      display: inline-block;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: black;
      min-width: 240px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
      padding: 12px 16px;
      right: 0;
      top: 100%;
      transform: translateX(-20%);
    }

    .dropdown-content a {
    color: white;
    font-style: normal;
    font-size: 16px;
    display: block;
    margin-bottom: 8px;
}

    .dropdown:hover .dropdown-content {
      display: block;
    }
  </style>
	<meta name="viewport" content="width=device-width, initial-scale=.0">
	<link rel="stylesheet" href="css/estilos.css">
	<link rel="stylesheet" href="style.css" />
	<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet"> 
	<title>FUTYSEX</title>
</head>
<body>
<header>
		<div id="nav" class="nav">
			<img class="nav__logo" src="images/netflix-logo.png" alt="" />
			<nav>
			          <a href="indextv.php">Inicio</a>
					  <a href="CanalesPorno.php" class="activo">Canales +18</a>
				  </nav>
				  <div class="dropdown">
    <img class="nav__avatar" src="images/netflix-avatar.png" alt="" />
    <div class="dropdown-content">
	  <a href="#">USUARIO:<?php echo $_SESSION['usuario'] ;?></a>
      <a href="#">DIAS RESTANTES:<?php echo $dias_restantes ;?></a>
      <a href="#">FECHA:<?php echo $marca_tiempo; ?></a>
      <a href="../php/salir.php">SALIR</a>
    </div>
  </div>



  <script>
    const dropdown = document.querySelector('.dropdown');
    const dropdownContent = document.querySelector('.dropdown-content');

    dropdown.addEventListener('click', function() {
      dropdownContent.style.display = dropdownContent.style.display === 'none' ? 'block' : 'none';
    });
  </script>
		  </div>
	</header>

	<main>
		<div class="pelicula-principal2">
			<div class="contenedor">
				<h3 class="titulo">SEXMEX</h3>
				<p class="descripcion">
					SexMex es un estudio pornográfico con sede en Guadalajara, Jalisco. Es el estudio de pornografía más grande de México y Latinoamérica.
				</p>
				<button role="button" class="boton"><i class="fas fa-play"></i>Reproducir</button>
				<button role="button" class="boton"><i class="fas fa-info-circle"></i>Más información</button>
			</div>
		</div>

			  <div class="peliculas-recomendadas contenedor">
				<div class="contenedor-titulo-controles">
					<h3>PORNO SUCIO Y DURO</h3>
					<div class="indicadores"></div>
				</div>
	
				<div class="contenedor-principal">
					<button role="button" id="flecha-izquierda" class="flecha-izquierda"><i class="fas fa-angle-left"></i></button>
	
					<div class="contenedor-carousel">
						<div class="carousel">
							<div class="pelicula">
								<a href="canales.php?id=sexmex"><img src="img/16.png" alt=""></a>
							</div>
							<div class="pelicula">
								<a href="canales.php?id=venus"><img src="img/17.png" alt=""></a>
							</div>
							<div class="pelicula">
								<a href="canales.php?id=playboy"><img src="img/18.png" alt=""></a>
							</div>
							<div class="pelicula">
								<a href="canales.php?id=sexmex"><img src="img/16.png" alt=""></a>
							</div>
							<div class="pelicula">
								<a href="canales.php?id=venus"><img src="img/17.png" alt=""></a>
							</div>
						</div>
					</div>
	
					<button role="button" id="flecha-derecha" class="flecha-derecha"><i class="fas fa-angle-right"></i></button>
				</div>
			</div>

	</main>
	
	<script src="https://kit.fontawesome.com/2c36e9b7b.js" crossorigin="anonymous"></script>
	<script src="js/main.js"></script>
</body>
</html>